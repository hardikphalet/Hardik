# Resources gathered from:
www.1001fonts.com/halo3-font.html
opengameart.org
