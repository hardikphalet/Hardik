package xyz.luan.flame.example.flame_crates_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
